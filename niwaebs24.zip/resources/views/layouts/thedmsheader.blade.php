{{-- for the document management system --}}
<link rel="stylesheet" href="{{asset('css/newcss/bootstrap.min.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('css/newcss/bootstrap-datepicker.min.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('css/newcss/font-awesome.min.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('css/newcss/jquery-ui.min.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('css/newcss/main.css')}}" type="text/css">
{{-- for the document management system --}}
