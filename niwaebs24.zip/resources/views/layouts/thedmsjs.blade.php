<script type="text/javascript" src="{{ asset('js/newjs/jquery-3.2.0.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/bootstrap-datepicker.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('js/newjs/jquery.dataTables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/dataTables.bootstrap4.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/dataTables.buttons.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/buttons.bootstrap4.min.js') }}">
    ">
</script>
<script type="text/javascript" src="{{ asset('js/newjs/buttons.print.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/pdfmake.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/vfs_fonts.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/buttons.html5.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/buttons.colVis.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/sum().js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/dataTables.select.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/newjs/dataTables.checkboxes.min.js') }}"></script>
