<?php
 
 use Illuminate\Support\Facades\Auth;
 
 $user = Auth::user();
 
 ?>

@include('layouts.menu')