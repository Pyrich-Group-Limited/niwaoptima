<!-- asset manager scripts/css -->
{{-- <link rel="stylesheet" href="{{ asset('plugin/datatables2/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/datepicker.css') }}"> --}}
<script src="{{ asset('js/jquery-3.5.1.min.js')}}"></script>
<script src="{{ asset('js/popper.min.js')}}"></script>
{{-- <script src="{{ asset('js/bootstrap.min.js')}}"></script> --}}
{{-- <script src="{{ asset('js/bootstrap-datepicker.js')}}"></script> --}}
<script src="{{ asset('js/jquery-ui.min.js')}}"></script>
<script src="{{ asset('plugin/chart/moment.min.js')}}"></script>
<script src="{{ asset('plugin/chart/Chart.min.js')}}"></script>
<script src="{{ asset('plugin/chart/utils.js')}}"></script>
<script src="{{ asset ('plugin/jqueryvalidation/jquery.validate.js')}}"></script>
<script src="{{ asset('plugin/jqueryvalidation/additional-methods.js')}}"></script>
<script src="{{ asset('plugin/datatables2/datatables.min.js')}}"></script>
<script src="{{ asset('js/general.js')}}"></script>
<!-- end asset manager scripts/css -->
<style>
.display-none {
    display: none;
}
</style>
