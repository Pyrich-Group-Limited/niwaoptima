@extends('emails.common')

@section('content')
    {!! $content !!}
@endsection
